<?php
	define("LC_SETTINGS",	"loancomparison_settings");
	define("LC_INTEREST",	"loancomparison_interest");
	define("LC_UPGRADE", 	"loancomparison_upgrade");
	define("LC_FORMNUMBER",	"loancomparison_formnumber");
	define("LC_KEY",		"loancomparison_key");
	define("LC_STYLE",		"loancomparison_style");
?>